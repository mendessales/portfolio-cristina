# 🧪 Testes de API com Postman + Newman

Este projeto contém testes automatizados de API usando [Postman](https://www.postman.com/) e [Newman](https://www.npmjs.com/package/newman), executando cenários contra a API pública [reqres.in](https://reqres.in).

## 🔧 Ferramentas
- Postman (para criação de coleções)
- Newman (CLI do Postman)
- GitHub Actions (para execução automática)

## ▶️ Como executar localmente

1. Instale o Node.js e o Newman:
```bash
npm install -g newman
```

2. Execute os testes:
```bash
newman run collection/reqres-tests.postman_collection.json -r cli,html --reporter-html-export tests-results/report.html
```

## ⚙️ Execução automática via GitHub Actions
A cada *push* neste repositório, o GitHub executa os testes automaticamente.

## 📁 Coleção de Testes
A coleção inclui:
- ✅ Criar usuário (POST)
- ❌ Login com senha inválida (POST)
- 🔍 Listar usuários (GET)
